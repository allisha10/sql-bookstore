# Bookstore SQL Project

This repository contains a sample SQL project that simulates a basic bookstore system. The goal of the project is to demonstrate relational database concepts using SQL including table creation, foreign key relationships, data insertion, and basic queries.

## 📄 Files Included

- `bookstore_project.sql`: Contains SQL code to create the database schema, insert sample data, and run example queries.

## 🧱 Database Structure

**Tables:**
- `Authors`: Stores author information.
- `Books`: Stores book titles, prices, and links to authors.
- `Sales`: Stores sales transactions with quantity and date.

## 🧪 Example Queries

The script includes:
- A join between `Books` and `Authors` to list books with author names
- Aggregation of total books sold from the `Sales` table

## 💻 How to Use

1. Open [https://www.db-fiddle.com/](https://www.db-fiddle.com/)
2. Choose **MySQL 8.0**
3. Paste the SQL code from `bookstore_project.sql`
4. Click **Build Schema**
5. Run the included queries in the Query panel to see results

## 🛠️ Technologies Used

- SQL (MySQL-compatible)
- GitHub (for version control and sharing)
- DB Fiddle (for interactive SQL testing)

---

Created as part of a personal learning project to demonstrate SQL skills.
